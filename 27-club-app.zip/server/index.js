require("dotenv").config();
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const QRCode = require("qrcode");
const { pool, initDb } = require("./db");
const otp = require("./otp-provider");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error("JWT_SECRET must be at least 32 characters. Set a long random secret.");
  process.exit(1);
}

app.use(helmet());
app.use(cors({ origin: process.env.APP_ORIGIN || "http://localhost:3000" }));
app.use(express.json({
  limit: "32kb",
  verify: (req, _res, buf) => {
    if (req.originalUrl.startsWith("/api/payments/webhook")) req.rawBody = Buffer.from(buf);
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: true, legacyHeaders: false });

function normalizePhone(input) {
  const phone = String(input || "").replace(/[\\s()-]/g, "");
  if (!/^\\+?[1-9]\\d{7,14}$/.test(phone)) return null;
  return phone.startsWith("+") ? phone : `+${phone}`;
}
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\\s+/i, "");
  try {
    if (!token) throw new Error("missing");
    req.user = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ["HS256"] });
    next();
  } catch {
    res.status(401).json({ error: "Please sign in again." });
  }
}
function safeEqualHex(a, b) {
  try {
    const aa = Buffer.from(a, "hex"), bb = Buffer.from(b, "hex");
    return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
  } catch { return false; }
}
app.use("/api", apiLimiter);

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "27-club-api" }));

app.post("/api/auth/request-otp", authLimiter, async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  if (!phone) return res.status(400).json({ error: "Enter a valid phone number with country code." });
  try {
    await otp.sendOtp(phone);
    res.json({ ok: true, message: "If the number is eligible, an OTP has been sent." });
  } catch (e) {
    res.status(e.status || 503).json({ error: e.status ? e.message : "OTP service is not configured." });
  }
});

app.post("/api/auth/verify-otp", authLimiter, async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || "");
  if (!phone || !/^\\d{4,8}$/.test(code)) return res.status(400).json({ error: "Invalid phone number or OTP." });
  try {
    const verified = await otp.verifyOtp(phone, code);
    if (!verified) return res.status(401).json({ error: "OTP is invalid or expired." });
    const result = await pool.query(
      "INSERT INTO users(phone) VALUES($1) ON CONFLICT(phone) DO UPDATE SET phone=EXCLUDED.phone RETURNING id, phone, points",
      [phone]
    );
    const user = result.rows[0];
    const token = jwt.sign({ sub: String(user.id), phone: user.phone }, process.env.JWT_SECRET, { algorithm: "HS256", expiresIn: "2h", issuer: "27-club" });
    res.json({ token, user });
  } catch (e) {
    res.status(e.status || 503).json({ error: e.status ? e.message : "Unable to verify OTP right now." });
  }
});

app.get("/api/me", auth, async (req, res) => {
  const r = await pool.query("SELECT id, phone, points, created_at FROM users WHERE id=$1", [req.user.sub]);
  if (!r.rowCount) return res.status(404).json({ error: "Account not found." });
  res.json({ user: r.rows[0] });
});

app.get("/api/tasks", auth, async (req, res) => {
  const r = await pool.query(`
    SELECT t.id,t.title,t.description,t.points,
      EXISTS(SELECT 1 FROM task_completions c WHERE c.user_id=$1 AND c.task_id=t.id) AS completed
    FROM tasks t WHERE t.active=true ORDER BY t.id`, [req.user.sub]);
  res.json({ tasks: r.rows });
});

app.post("/api/tasks/:id/complete", auth, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const task = await client.query("SELECT id,title,points FROM tasks WHERE id=$1 AND active=true", [req.params.id]);
    if (!task.rowCount) { await client.query("ROLLBACK"); return res.status(404).json({ error: "Task not found." }); }
    const t = task.rows[0];
    const completion = await client.query(
      "INSERT INTO task_completions(user_id,task_id) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING task_id",
      [req.user.sub, t.id]
    );
    if (!completion.rowCount) { await client.query("ROLLBACK"); return res.status(409).json({ error: "This task has already been completed." }); }
    await client.query("UPDATE users SET points=points+$1 WHERE id=$2", [t.points, req.user.sub]);
    const reference = `PTS-${crypto.randomUUID()}`;
    await client.query(
      "INSERT INTO transactions(user_id,kind,points_delta,reference,status,description) VALUES($1,'points_credit',$2,$3,'completed',$4)",
      [req.user.sub, t.points, reference, `Completed task: ${t.title}`]
    );
    const balance = await client.query("SELECT points FROM users WHERE id=$1", [req.user.sub]);
    await client.query("COMMIT");
    res.json({ ok: true, pointsAdded: t.points, points: balance.rows[0].points });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(500).json({ error: "Could not complete task." });
  } finally { client.release(); }
});

app.get("/api/transactions", auth, async (req, res) => {
  const r = await pool.query(
    "SELECT id,kind,amount_paise,points_delta,reference,status,description,created_at FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100",
    [req.user.sub]
  );
  res.json({ transactions: r.rows });
});

// This creates a UPI payment intent + QR image. It does NOT prove payment.
// Payment remains pending until a verified provider webhook/reconciliation confirms it.
app.post("/api/payments/order", auth, async (req, res) => {
  const amountPaise = Number(req.body.amountPaise);
  const purpose = String(req.body.purpose || "").trim().slice(0, 100);
  if (!Number.isInteger(amountPaise) || amountPaise < 100 || amountPaise > 1000000) {
    return res.status(400).json({ error: "Amount must be between ₹1 and ₹10,000." });
  }
  if (!purpose) return res.status(400).json({ error: "Describe the genuine product or service being purchased." });
  if (!process.env.UPI_ID || !process.env.UPI_MERCHANT_NAME) {
    return res.status(503).json({ error: "Merchant UPI details are not configured." });
  }
  const reference = `27C-${crypto.randomUUID()}`;
  const rupees = (amountPaise / 100).toFixed(2);
  const upi = `upi://pay?pa=${encodeURIComponent(process.env.UPI_ID)}&pn=${encodeURIComponent(process.env.UPI_MERCHANT_NAME)}&am=${rupees}&cu=INR&tn=${encodeURIComponent(purpose)}&tr=${encodeURIComponent(reference)}`;
  const qrDataUrl = await QRCode.toDataURL(upi, { errorCorrectionLevel: "M", margin: 2, width: 320 });
  await pool.query(
    "INSERT INTO transactions(user_id,kind,amount_paise,reference,status,description) VALUES($1,'payment_pending',$2,$3,'pending',$4)",
    [req.user.sub, amountPaise, reference, purpose]
  );
  res.status(201).json({
    reference, amountPaise, currency: "INR", upiIntent: upi, qrDataUrl, status: "pending",
    message: "Payment is pending. Do not deliver paid goods/services until verified server-side."
  });
});

// Generic webhook template. Adapt to your provider's official signature scheme and event payload.
// Expected signature header: x-27club-signature = hex HMAC-SHA256(raw request body).
// A production provider may require a different signing method; do not use this template unchanged.
app.post("/api/payments/webhook", async (req, res) => {
  const secret = process.env.PAYMENT_WEBHOOK_SECRET;
  const signature = String(req.headers["x-27club-signature"] || "");
  if (!secret || !/^[a-f0-9]{64}$/i.test(signature)) return res.status(401).send("Unauthorized");
  const expected = crypto.createHmac("sha256", secret).update(req.rawBody || Buffer.alloc(0)).digest("hex");
  if (!safeEqualHex(signature, expected)) return res.status(401).send("Invalid signature");
  let event;
  try { event = req.body; } catch { return res.status(400).send("Bad JSON"); }
  // Only process provider-confirmed successful payments. Never trust a client callback.
  if (event.type !== "payment.succeeded" || !event.reference || !event.providerReference || event.amountPaise == null) {
    return res.status(200).send("Ignored");
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const tx = await client.query("SELECT * FROM transactions WHERE reference=$1 FOR UPDATE", [String(event.reference)]);
    if (!tx.rowCount) { await client.query("ROLLBACK"); return res.status(404).send("Unknown reference"); }
    const row = tx.rows[0];
    if (Number(row.amount_paise) !== Number(event.amountPaise)) { await client.query("ROLLBACK"); return res.status(400).send("Amount mismatch"); }
    if (row.status !== "paid") {
      await client.query(
        "UPDATE transactions SET kind='payment_paid', status='paid', provider_reference=$1 WHERE id=$2",
        [String(event.providerReference), row.id]
      );
    }
    await client.query("COMMIT");
    res.status(200).send("OK");
  } catch {
    await client.query("ROLLBACK");
    res.status(500).send("Retry later");
  } finally { client.release(); }
});

app.use(express.static(path.join(__dirname, "..", "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

initDb().then(() => app.listen(PORT, () => console.log(`27 Club listening on ${PORT}`)))
  .catch(err => { console.error("Database initialization failed:", err.message); process.exit(1); });
