const { Pool } = require("pg");

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      points INTEGER NOT NULL DEFAULT 0 CHECK (points >= 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      points INTEGER NOT NULL CHECK (points > 0),
      active BOOLEAN NOT NULL DEFAULT TRUE
    );
    CREATE TABLE IF NOT EXISTS task_completions (
      user_id BIGINT NOT NULL REFERENCES users(id),
      task_id TEXT NOT NULL REFERENCES tasks(id),
      completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY(user_id, task_id)
    );
    CREATE TABLE IF NOT EXISTS transactions (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id),
      kind TEXT NOT NULL CHECK (kind IN ('points_credit','payment_pending','payment_paid','payment_failed')),
      amount_paise BIGINT,
      points_delta INTEGER,
      reference TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL,
      description TEXT NOT NULL,
      provider_reference TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS transactions_user_created_idx ON transactions(user_id, created_at DESC);
    INSERT INTO tasks(id,title,description,points) VALUES
      ('daily-checkin','Daily check-in','Check in to collect non-cash loyalty points.',10),
      ('learn-safety','Learn online safety','Read the online safety tips.',20),
      ('profile-basics','Complete profile basics','Review your account details.',15)
    ON CONFLICT (id) DO NOTHING;
  `);
}
module.exports = { pool, initDb };
