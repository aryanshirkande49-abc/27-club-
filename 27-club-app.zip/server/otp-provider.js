// Implement this adapter against the CURRENT official API documentation of your SMS OTP vendor.
// Do not store plaintext OTPs, log them, or use a hard-coded development OTP.
// The app intentionally fails closed until a real provider is configured.
async function sendOtp(phone) {
  if (!process.env.OTP_PROVIDER || process.env.OTP_PROVIDER === "disabled") {
    const err = new Error("OTP provider is not configured. Configure a real SMS OTP provider first.");
    err.status = 503;
    throw err;
  }
  throw new Error("OTP adapter not implemented. Implement the selected provider's official send/verify APIs.");
}

async function verifyOtp(phone, code) {
  if (!process.env.OTP_PROVIDER || process.env.OTP_PROVIDER === "disabled") {
    const err = new Error("OTP provider is not configured.");
    err.status = 503;
    throw err;
  }
  throw new Error("OTP adapter not implemented. Implement the selected provider's official send/verify APIs.");
}
module.exports = { sendOtp, verifyOtp };
