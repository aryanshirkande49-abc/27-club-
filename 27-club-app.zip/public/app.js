const $ = (id) => document.getElementById(id);
let token = sessionStorage.getItem("club27_token") || "";
let currentUser = null;

function showMessage(id, message, good=false) {
  const el = $(id); el.textContent = message || ""; el.style.color = good ? "#6fe0b4" : "#ffd9a1";
}
async function api(path, options={}) {
  const headers = { "Content-Type":"application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(path, { ...options, headers });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function showApp() {
  $("authPanel").classList.add("hidden"); $("appPanel").classList.remove("hidden"); $("logoutBtn").classList.remove("hidden");
}
function signOut() {
  token = ""; currentUser = null; sessionStorage.removeItem("club27_token");
  $("appPanel").classList.add("hidden"); $("authPanel").classList.remove("hidden"); $("logoutBtn").classList.add("hidden");
}
$("logoutBtn").addEventListener("click", signOut);
$("requestOtp").addEventListener("click", async () => {
  showMessage("authMessage", "");
  try {
    await api("/api/auth/request-otp", {method:"POST", body:JSON.stringify({phone:$("phone").value})});
    $("otpArea").classList.remove("hidden");
    showMessage("authMessage", "OTP request sent. Check your SMS.", true);
  } catch(e) { showMessage("authMessage", e.message); }
});
$("verifyOtp").addEventListener("click", async () => {
  try {
    const data = await api("/api/auth/verify-otp", {method:"POST", body:JSON.stringify({phone:$("phone").value,code:$("otp").value})});
    token = data.token; sessionStorage.setItem("club27_token", token);
    await loadDashboard();
  } catch(e) { showMessage("authMessage", e.message); }
});
async function loadDashboard() {
  const data = await api("/api/me"); currentUser = data.user; showApp();
  $("points").innerHTML = `${Number(currentUser.points).toLocaleString()} <small>pts</small>`;
  await loadTasks(); await loadHistory();
}
async function loadTasks() {
  const {tasks} = await api("/api/tasks");
  $("taskList").innerHTML = "";
  if (!tasks.length) $("taskList").textContent = "No tasks available.";
  for (const t of tasks) {
    const article = document.createElement("article"); article.className = "task";
    const icon = document.createElement("div"); icon.className = "task-icon"; icon.textContent = "✦";
    const copy = document.createElement("div"); copy.className = "task-copy";
    const title = document.createElement("strong"); title.textContent = t.title;
    const desc = document.createElement("small"); desc.textContent = t.description;
    copy.append(title, desc);
    const pts = document.createElement("div"); pts.className = "task-points"; pts.textContent = `+${t.points}`;
    const btn = document.createElement("button"); btn.textContent = t.completed ? "Completed" : "Collect";
    btn.disabled = Boolean(t.completed);
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try { await api(`/api/tasks/${encodeURIComponent(t.id)}/complete`, {method:"POST",body:"{}"}); await loadDashboard(); }
      catch(e) { showMessage("globalMessage", e.message); btn.disabled = false; }
    });
    article.append(icon, copy, pts, btn); $("taskList").append(article);
  }
}
async function loadHistory() {
  try {
    const {transactions} = await api("/api/transactions");
    $("historyList").innerHTML = "";
    if (!transactions.length) { $("historyList").textContent = "No transactions yet."; return; }
    for (const tx of transactions) {
      const item = document.createElement("article"); item.className = "history-item";
      const left = document.createElement("div");
      const title = document.createElement("strong"); title.textContent = tx.description;
      const date = document.createElement("small"); date.textContent = new Date(tx.created_at).toLocaleString();
      const status = document.createElement("span"); status.className = "status"; status.textContent = tx.status;
      left.append(title, date, status);
      const right = document.createElement("div"); right.className = "amount";
      const val = document.createElement("strong");
      if (tx.points_delta != null) val.textContent = `${Number(tx.points_delta)>0?"+":""}${tx.points_delta} pts`;
      else val.textContent = tx.amount_paise == null ? "—" : `₹${(Number(tx.amount_paise)/100).toFixed(2)}`;
      right.append(val); item.append(left,right); $("historyList").append(item);
    }
  } catch(e) { showMessage("globalMessage", e.message); }
}
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active", b===btn));
  document.querySelectorAll(".tab-content").forEach(el=>el.classList.add("hidden"));
  $(`${btn.dataset.tab}Tab`).classList.remove("hidden");
  if (btn.dataset.tab === "history") loadHistory();
}));
$("refreshHistory").addEventListener("click", loadHistory);
$("createPayment").addEventListener("click", async () => {
  const amount = Number($("amount").value);
  const purpose = $("purpose").value.trim();
  $("paymentResult").classList.add("hidden");
  try {
    const order = await api("/api/payments/order", {method:"POST",body:JSON.stringify({amountPaise:Math.round(amount*100),purpose})});
    const result = $("paymentResult"); result.classList.remove("hidden"); result.innerHTML = "";
    const heading = document.createElement("strong"); heading.textContent = "Payment pending";
    const ref = document.createElement("p"); ref.textContent = `Reference: ${order.reference}`;
    const qr = document.createElement("img"); qr.alt = "UPI payment QR code"; qr.src = order.qrDataUrl;
    const hint = document.createElement("p"); hint.className = "tiny"; hint.textContent = "Scan with a UPI app. This app will not mark it paid until the server receives verified confirmation.";
    const link = document.createElement("a"); link.href = order.upiIntent; link.textContent = "Open UPI app"; link.style.color = "#c6bbff";
    result.append(heading,ref,qr,link,hint); await loadHistory();
  } catch(e) { showMessage("globalMessage", e.message); }
});
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(()=>{}));
if (token) loadDashboard().catch(()=>signOut());
