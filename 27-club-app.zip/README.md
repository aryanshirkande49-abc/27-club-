# 27 Club — Rewards & Tasks (starter project)

A deployable starter for a mobile-first rewards website and installable Android PWA.

## Included
- Mobile-first web app and PWA manifest/service worker
- Backend API (Node.js + Express + PostgreSQL)
- OTP authentication integration points (fails closed unless a real SMS provider is configured)
- Reward tasks and points ledger
- Transaction history
- UPI QR payment-order flow for legitimate purchases
- Signed payment-webhook endpoint template
- Docker Compose for local development

## Important payment/authentication limits
This is a starter project, not a live financial service. No payment is marked paid just because a QR was scanned, a UPI app was opened, or a screenshot was uploaded. A static/dynamic UPI QR alone cannot securely confirm payment to your server. For automatic confirmation, integrate an RBI-regulated/acquiring payment provider that supports server-side payment status APIs and signed webhooks, or reconcile payments from an authorized bank/provider integration. The included webhook is a generic HMAC template and must be adapted to the chosen provider's exact signature scheme.

OTP is disabled unless an SMS provider is configured. Do not ship with test OTPs or bypass codes. Use a provider that is available to your business and follow its current documentation.

The included points are non-cash loyalty points. This starter does not implement cash withdrawals, betting, wagering, or cash-equivalent rewards. Use payments only for genuine, clearly described purchases or services and follow applicable laws and provider terms.

## Requirements
- Node.js 20+
- PostgreSQL 15+
- An SMS OTP provider account and credentials
- A payment provider / merchant account for automatic payment verification
- HTTPS domain for production

## Local setup
1. Copy environment file:
   ```bash
   cp .env.example .env
   ```
2. Set `DATABASE_URL`, `JWT_SECRET`, `OTP_PROVIDER`, SMS credentials, `UPI_ID`, and webhook secret in `.env`.
3. Start PostgreSQL and the API:
   ```bash
   docker compose up --build
   ```
4. Open `http://localhost:3000`.
5. OTP endpoints intentionally return an error until a real OTP adapter is implemented/configured. Implement `server/otp-provider.js` using your chosen SMS vendor's current official API. Never log OTPs in production.

## Production deployment outline
1. Create a managed PostgreSQL database and a Node.js hosting service (for example, a reputable PaaS).
2. Deploy the `server/` app and set environment variables in the host dashboard; do not commit `.env`.
3. Configure the SMS OTP adapter and test delivery, expiry, rate limits, and abuse prevention.
4. Integrate a payment provider's official order/status APIs and webhook signature verification. Keep all secret keys server-side.
5. Configure HTTPS, a custom domain, backups, database migrations, error monitoring, and a privacy policy/terms page.
6. Test webhook replay handling and duplicate event handling before enabling production payments.
7. Host the PWA on the same domain or configure CORS carefully.
8. For Android packaging, install Capacitor after the web app is deployed:
   ```bash
   npm install
   npx cap init "27 Club" "com.example.twentysevenclub"
   npx cap add android
   npx cap copy android
   npx cap open android
   ```
   Use your own unique Android application ID before release. For a production Android app, use Android Studio to create a signed release build.

## API overview
- `POST /api/auth/request-otp` — requests OTP via configured provider
- `POST /api/auth/verify-otp` — verifies OTP and returns a JWT
- `GET /api/me` — current account
- `GET /api/tasks` — available tasks
- `POST /api/tasks/:id/complete` — completes eligible demo task once and credits non-cash points
- `GET /api/transactions` — points and payment ledger
- `POST /api/payments/order` — creates a pending payment order and UPI intent/QR payload
- `POST /api/payments/webhook` — generic HMAC webhook template; adapt to provider before use

## Security checklist
- Use a long random JWT secret (32+ bytes) and rotate secrets securely.
- Use HTTPS only in production.
- Add provider-specific webhook signature verification and idempotency.
- Keep merchant secrets out of frontend code and Git.
- Add fraud review, support contact, privacy policy, terms, data retention and account deletion processes.
- Have a qualified adult/business owner manage merchant onboarding if you are under 18.
